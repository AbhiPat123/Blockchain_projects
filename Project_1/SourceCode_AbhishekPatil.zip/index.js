'use strict';
const productcontract = require('./productcontract.js');
module.exports.contracts = [productcontract];
